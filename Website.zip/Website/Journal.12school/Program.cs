namespace Journal._12school
{
    public class Program
    { 
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();


            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }

    public static class ClassSwitcher 
    {
        public static string Switch(ref string classes) 
        {
            string data = null;

            if (classes.Length == 3)
            {
                if (classes[0..2] == "10")
                {
                    data = "TEN";
                }
                else if (classes[0..2] == "11")
                {
                    data = "ELEVEN";
                }
            }
            else
            {
                switch (classes[0..1])
                {
                    case "9":
                        data = "NINE";
                        break;
                    case "8":
                        data = "EIGHT";
                        break;
                    case "7":
                        data = "SEVEN";
                        break;
                    case "6":
                        data = "SIX";
                        break;
                    case "5":
                        data = "FIVE";
                        break;
                    case "4":
                        data = "FORE";
                        break;
                    case "3":
                        data = "THRE";
                        break;
                    case "2":
                        data = "TWOO";
                        break;
                    case "1":
                        data = "ONE";
                        break;
                }
            }

            switch (classes[classes.Length - 1])
            {
                case '�':
                    data += "�";
                    break;
                case '�':
                    data += "b";
                    break;
                case '�':
                    data += "v";
                    break;
                case '�':
                    data += "g";
                    break;
                case '�':
                    data += "d";
                    break;
                case '�':
                    data += "e";
                    break;
            }
            classes = data;
            return data;
        }
        public static string SwitchNonRef(ref string classes)
        {
            string data = null;

            if (classes.Length == 3)
            {
                if (classes[0..2] == "10")
                {
                    data = "TEN";
                }
                else if (classes[0..2] == "11")
                {
                    data = "ELEVEN";
                }
            }
            else
            {
                switch (classes[0..1])
                {
                    case "9":
                        data = "NINE";
                        break;
                    case "8":
                        data = "EIGHT";
                        break;
                    case "7":
                        data = "SEVEN";
                        break;
                    case "6":
                        data = "SIX";
                        break;
                    case "5":
                        data = "FIVE";
                        break;
                    case "4":
                        data = "FORE";
                        break;
                    case "3":
                        data = "THRE";
                        break;
                    case "2":
                        data = "TWOO";
                        break;
                    case "1":
                        data = "ONE";
                        break;
                }
            }

            switch (classes[classes.Length - 1])
            {
                case '�':
                    data += "�";
                    break;
                case '�':
                    data += "b";
                    break;
                case '�':
                    data += "v";
                    break;
                case '�':
                    data += "g";
                    break;
                case '�':
                    data += "d";
                    break;
                case '�':
                    data += "e";
                    break;
            }
            return data;
        }
    }
}

