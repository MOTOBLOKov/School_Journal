﻿global using System.Data.SqlClient;
global using Microsoft.AspNetCore.Mvc;
global using Journal._12school.Models;
global using System.Diagnostics;
global using Journal._12school;