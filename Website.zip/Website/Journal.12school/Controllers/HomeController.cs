namespace Journal._12school.Controllers
{
    public class HomeController : Controller
    {
        public SqlConnection Connection = new("Server=(localdb)\\mssqllocaldb;Database=master;Trusted_Connection=True;MultipleActiveResultSets=true;");

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger) => _logger = logger;

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            bool isvalidate = true;

            if (Request.Cookies["n"] == null)
            { isvalidate = false; Console.WriteLine("n null"); }
            else if (Request.Cookies["s"] == null)
            { isvalidate = false; Console.WriteLine("s null"); }
            else if (Request.Cookies["p"] == null)
            { isvalidate = false; Console.WriteLine("p null"); }
            else if (Request.Cookies["c"] == null)
            { isvalidate = false; Console.WriteLine("c null"); }

            if (isvalidate)
            {
                try
                {
                    if (Connection.State == System.Data.ConnectionState.Closed)
                        await Connection.OpenAsync();

                    using (SqlCommand com1 = new SqlCommand($"USE ACCOUNTS SELECT * FROM ACCOUNTSINFO WHERE CLASES = '{Request.Cookies["c"]}' and USERNAME = '{Request.Cookies["n"]}' and USERSURNAME = '{Request.Cookies["s"]}' and USERPASSWORD ='{Request.Cookies["p"]}';", Connection))
                    {
                        using (SqlDataReader read = await com1.ExecuteReaderAsync())
                        {
                            await read.ReadAsync();
                            if (read.GetValue(0) != null && read.GetValue(1) != null && read.GetValue(2) != null && read.GetValue(3) != null)
                                return Redirect("~/Home/Mycabinet");
                        }
                    }
                }
                catch (Exception ex)
                {
                    await Console.Out.WriteLineAsync(ex.Message);
                    return View(true);
                }
            }
            return View(true);
        }
        [HttpPost]
        public async Task<IActionResult> Index(string name, string surname, string password, string trypassword, string classes)
        {
            if (password != trypassword)
                return View(false);

            if (classes == "-----�������� �����-----")
                return View(false);

            ClassSwitcher.Switch(ref classes);

            if (Connection.State == System.Data.ConnectionState.Closed)
                await Connection.OpenAsync();
            try
            {
                await Console.Out.WriteLineAsync($"���: {name}");
                await Console.Out.WriteLineAsync($"�������: {surname}");
                await Console.Out.WriteLineAsync($"������: {password} : {trypassword}");
                await Console.Out.WriteLineAsync($"�����: {classes}");
                await Console.Out.WriteLineAsync($"�������������� �������: USE ACCOUNTS SELECT * FROM ACCOUNTSINFO WHERE CLASES = '{classes}' and USERNAME = '{name}' and USERSURNAME = '{surname}';");

                using (SqlCommand com1 = new SqlCommand($"USE ACCOUNTS SELECT * FROM ACCOUNTSINFO WHERE CLASES = '{classes}' and USERNAME = '{name}' and USERSURNAME = '{surname}';", Connection))
                {
                    using (SqlDataReader read = await com1.ExecuteReaderAsync())
                    {
                        await read.ReadAsync();
                        if (read.GetValue(0) != null && read.GetValue(1) != null && read.GetValue(2) != null && read.GetValue(3) != null)
                            return View(false);
                    }
                }
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync($"{name} {surname}:{ex.Message}");
            }

            try
            {
                if (Connection.State == System.Data.ConnectionState.Closed)
                    await Connection.OpenAsync();

                using (SqlCommand command = new SqlCommand($"USE CLASSROOMS SELECT * FROM {classes} WHERE SURNAME = '{surname.Trim()}' AND NAME = '{name.Trim()}'", Connection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (reader.HasRows)
                        {
                            await reader.ReadAsync();

                            if (reader.GetValue(0) != null && reader.GetValue(1) != null)
                            {
                                Response.Cookies.Append("n", name.Trim());
                                Response.Cookies.Append("s", surname.Trim());
                                Response.Cookies.Append("p", password.Trim());
                                Response.Cookies.Append("c", classes.Trim());
                                await Console.Out.WriteLineAsync(classes);
                                await Console.Out.WriteLineAsync(surname + " " + name + " " + password);
                                using (SqlCommand command1 = new SqlCommand($"USE ACCOUNTS INSERT INTO ACCOUNTSINFO(CLASES , USERNAME , USERSURNAME , USERPASSWORD) VALUES('{classes}','{name}','{surname}','{password}');", Connection))
                                {
                                    await reader.CloseAsync();
                                    await command1.ExecuteNonQueryAsync();
                                }
                            }
                            else
                            {
                                return View(false);
                            }
                        }
                        else
                        {
                            return View(false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return View(false);
            }

            return Redirect("~/Home/Mycabinet");
        }

        [HttpGet]
        public async Task<IActionResult> UserHaveAccount()
        {
            return View(false);
        }
        [HttpPost]
        public async Task<IActionResult> UserHaveAccount(string name, string surname, string password, string classes)
        {
            try
            {
                ClassSwitcher.Switch(ref classes);
                if (Connection.State == System.Data.ConnectionState.Closed)
                    await Connection.OpenAsync();

                await Console.Out.WriteLineAsync($"���: {name}");
                await Console.Out.WriteLineAsync($"�������: {surname}");
                await Console.Out.WriteLineAsync($"������: {password}");
                await Console.Out.WriteLineAsync($"�����: {classes}");
                await Console.Out.WriteLineAsync($"�������������� �������: USE ACCOUNTS SELECT * FROM ACCOUNTSINFO WHERE CLASES = '{classes}' and USERNAME = '{name}' and USERSURNAME = '{surname}' and USERPASSWORD = '{password}';");

                using (SqlCommand command = new SqlCommand($"USE ACCOUNTS SELECT * FROM ACCOUNTSINFO WHERE CLASES = '{classes}' and USERNAME = '{name}' and USERSURNAME = '{surname}' and USERPASSWORD = '{password}';", Connection))
                {
                    using (SqlDataReader read = await command.ExecuteReaderAsync())
                    {
                        await read.ReadAsync();

                        if (read.GetValue(0) != null && read.GetValue(1) != null && read.GetValue(2) != null && read.GetValue(3) != null)
                        {
                            Response.Cookies.Append("n", name);
                            Response.Cookies.Append("s", surname);
                            Response.Cookies.Append("p", password);
                            Response.Cookies.Append("c", classes);
                            return Redirect("~/Home/Mycabinet");
                        }
                        else { return View(false); }
                    }
                }
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                return View(true);
            }
        }

        [HttpGet]
        public async Task<IActionResult> ImTeacher()
        {
            return View(true);
        }
        [HttpPost]
        public async Task<IActionResult> ImTeacher(string name, string surname, string lastname, string password, string trypassword)
        {
            try
            {
                if (password != trypassword)
                    return View(false);

                if (Connection.State == System.Data.ConnectionState.Closed)
                    await Connection.OpenAsync();

                using (SqlCommand command = new SqlCommand($"USE TEACHERS SELECT * FROM PERSON WHERE SNL = '{surname.Trim() + " " + name.Trim() + " " + lastname.Trim()}'", Connection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (reader.HasRows)
                        {
                            await reader.ReadAsync();

                            if (reader.GetValue(0) != null)
                            {
                                try
                                {
                                    using (SqlCommand command2 = new SqlCommand($"USE ACCOUNTS SELECT * FROM ACCOUNTSINFO WHERE CLASES ='isteacher' and USERNAME ='{name.Trim()}' and USERSURNAME ='{surname.Trim()}' and USERPASSWORD ='{password.Trim()}';", Connection))
                                    {

                                        await reader.CloseAsync();

                                        using (SqlDataReader reader1 = await command2.ExecuteReaderAsync())
                                        {
                                            if (!reader1.HasRows)
                                            {
                                                if (reader1.GetValue(0) != null && reader1.GetValue(1) != null && reader1.GetValue(2) != null && reader1.GetValue(3) != null)
                                                {
                                                    return View(false);
                                                }
                                            }
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Response.Cookies.Append("n", name.Trim());
                                    Response.Cookies.Append("s", surname.Trim());
                                    Response.Cookies.Append("p", password.Trim());
                                    Response.Cookies.Append("c", "isteacher");

                                    using (SqlCommand command1 = new SqlCommand($"USE ACCOUNTS INSERT INTO ACCOUNTSINFO(CLASES , USERNAME , USERSURNAME , USERPASSWORD) VALUES('isteacher','{name}','{surname}','{password}');", Connection))
                                    {
                                        await command1.ExecuteNonQueryAsync();
                                    }
                                    await Console.Out.WriteLineAsync(ex.Message);
                                    return Redirect("~/Home/Mycabinet");
                                }
                            }
                            else
                            {
                                return View(false);
                            }
                        }
                        else
                        {
                            return View(false);
                        }
                    }
                }
                return View(false);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return View(false);
            }
        }
        [HttpGet]
        public async Task<IActionResult> ImTeacherEntry()
        {
            return View(true);
        }
        [HttpPost]
        public async Task<IActionResult> ImTeacherEntry(string name, string surname, string lastname, string password)
        {
            try
            {
                if (Connection.State == System.Data.ConnectionState.Closed)
                    await Connection.OpenAsync();

                using (SqlCommand command = new SqlCommand($"USE TEACHERS SELECT * FROM PERSON WHERE SNL = '{surname.Trim() + " " + name.Trim() + " " + lastname.Trim()}'", Connection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        await reader.ReadAsync();

                        if (reader.GetValue(0) != null)
                        {
                            await reader.CloseAsync();

                            using (SqlCommand command1 = new SqlCommand($"USE ACCOUNTS SELECT * FROM ACCOUNTSINFO WHERE CLASES='isteacher' and USERNAME='{name}' and USERSURNAME ='{surname}' and USERPASSWORD ='{password}';", Connection))
                            {
                                using (SqlDataReader reader1 = await command1.ExecuteReaderAsync())
                                {
                                    await reader1.ReadAsync();

                                    if (reader1.GetValue(0) != null && reader1.GetValue(1) != null && reader1.GetValue(2) != null && reader1.GetValue(3) != null)
                                    {
                                        Response.Cookies.Append("n", name.Trim());
                                        Response.Cookies.Append("s", surname.Trim());
                                        Response.Cookies.Append("p", password.Trim());
                                        Response.Cookies.Append("c", "isteacher");

                                        return Redirect("~/Home/Mycabinet");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                return View(false);
            }
            return View(false);
        }
        [HttpGet]
        public async Task<IActionResult> MyCabinet()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> MyCabinet(string classes)
        {
            if (ClassSwitcher.SwitchNonRef(ref classes) != null && ClassSwitcher.SwitchNonRef(ref classes) != "-��������-�����-")
            {
                Response.Cookies.Append("SC", ClassSwitcher.SwitchNonRef(ref classes));
                return Redirect("~/Home/SelectItem");
            }

            return View();
        }

        public async Task<IActionResult> Schedule()
        {
            return View();
        }

        public async Task<IActionResult> Marks()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> ClassMarks()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ClassMarks(List<string> markval , string homework)
        {
            string data = Request.Cookies["SC"];
            string cls = Request.Cookies["SI"];
            if (Connection.State == System.Data.ConnectionState.Closed)
                await Connection.OpenAsync();

            using (SqlCommand command = new SqlCommand($"USE CLASSROOMS SELECT * FROM {data}" , Connection)) 
            {
                using (SqlDataReader reader = await command.ExecuteReaderAsync()) 
                {
                    if (reader.HasRows) 
                    {
                        for (int i = 0; await reader.ReadAsync() ; i++) 
                        {
                            if (markval[i] != "-")
                            {
                                using (SqlCommand command1 = new SqlCommand($"USE MARKS INSERT INTO {data}_{reader.GetValue(0)}{reader.GetValue(1)}({cls}) VALUES('{markval[i]}');", Connection))
                                {
                                    await Console.Out.WriteLineAsync($"USE MARKS INSERT INTO {data}_{reader.GetValue(0)}{reader.GetValue(1)}({cls}) VALUES('{markval[i]}');");
                                    await command1.ExecuteNonQueryAsync();
                                }
                            }
                        }
                    }
                }
            }

            if (Connection.State == System.Data.ConnectionState.Closed)
                await Connection.OpenAsync();

            using (SqlCommand sqlCommand = new SqlCommand($"USE CLASESITEMS UPDATE {data} SET HOMEWORK = '{homework}' WHERE ITEMS = '{Request.Cookies["SI"]}'; " , Connection)) 
            {
                await sqlCommand.ExecuteNonQueryAsync();
            }

            return View();
        }

        [HttpGet]
        public async Task<IActionResult> SelectItem()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> SelectItem(string item)
        {
            if (item != "-��������-�������-") 
            {
                await Console.Out.WriteLineAsync(item);
                Response.Cookies.Append("SI" , item);
                return Redirect("~/Home/ClassMarks");
            }

            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

